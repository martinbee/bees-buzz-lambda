# bees-buzz-lambda
AWS lambda used to fetch articles for Bees Buzz News Hub
